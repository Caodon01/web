# modules/data/fetcher.py

import pandas as pd



class DataFetcher:
    """
    Mengambil dan menyiapkan data saham.
    """



    def __init__(self):

        pass




    def load_from_dataframe(self, data):

        """
        Memasukkan data yang sudah tersedia.

        Format wajib:

        date
        open
        high
        low
        close
        volume
        """

        df = data.copy()



        # memastikan urutan waktu

        if "date" in df.columns:

            df["date"] = pd.to_datetime(
                df["date"]
            )

            df = (
                df
                .sort_values("date")
                .reset_index(drop=True)
            )



        return df





    def load_csv(self, path):

        """
        Membaca data dari file CSV.
        """

        df = pd.read_csv(path)


        return self.load_from_dataframe(
            df
        )





    def get_latest(self, data, rows=100):

        """
        Mengambil data candle terakhir.
        """

        return (
            data
            .tail(rows)
            .reset_index(drop=True)
        )