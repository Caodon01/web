# modules/data/validator.py


class DataValidator:
    """
    Validasi data OHLCV sebelum analisa.
    """



    REQUIRED_COLUMNS = [

        "open",

        "high",

        "low",

        "close",

        "volume"

    ]



    def __init__(self, data):

        self.data = data.copy()





    def check_columns(self):

        """
        Mengecek kelengkapan kolom.
        """

        missing = []


        for column in self.REQUIRED_COLUMNS:

            if column not in self.data.columns:

                missing.append(column)



        return {

            "valid":
            len(missing) == 0,

            "missing":
            missing

        }





    def check_empty(self):

        """
        Mengecek data kosong.
        """

        empty = (
            self.data
            .isnull()
            .sum()
        )


        return {

            "valid":
            empty.sum() == 0,

            "empty":
            empty.to_dict()

        }





    def check_price(self):

        """
        Mengecek harga tidak negatif.
        """

        price_columns = [

            "open",
            "high",
            "low",
            "close"

        ]


        invalid = []


        for col in price_columns:

            if (
                self.data[col] <= 0
            ).any():

                invalid.append(col)



        return {

            "valid":
            len(invalid) == 0,

            "invalid":
            invalid

        }





    def check_candle_logic(self):

        """
        Mengecek logika candle.

        High harus paling tinggi.
        Low harus paling rendah.
        """

        invalid = []



        for index, row in self.data.iterrows():


            highest = max(
                row["open"],
                row["close"]
            )


            lowest = min(
                row["open"],
                row["close"]
            )


            if row["high"] < highest:

                invalid.append(index)



            if row["low"] > lowest:

                invalid.append(index)



        return {

            "valid":
            len(invalid) == 0,

            "invalid_rows":
            invalid

        }





    def validate(self):

        """
        Menjalankan semua pengecekan.
        """

        results = {

            "columns":
            self.check_columns(),

            "empty":
            self.check_empty(),

            "price":
            self.check_price(),

            "candle":
            self.check_candle_logic()

        }



        overall = all(

            item["valid"]

            for item in results.values()

        )


        return {

            "valid":
            overall,

            "details":
            results

        }