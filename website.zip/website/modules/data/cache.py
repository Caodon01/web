# modules/data/cache.py


import time



class DataCache:
    """
    Sistem penyimpanan sementara data saham.
    """



    def __init__(self, expiry=300):

        """
        expiry dalam detik.

        Default:
        5 menit
        """

        self.storage = {}

        self.expiry = expiry





    def save(
        self,
        key,
        data
    ):

        """
        Menyimpan data.
        """

        self.storage[key] = {

            "data": data,

            "time": time.time()

        }




    def get(
        self,
        key
    ):

        """
        Mengambil data dari cache.
        """

        if key not in self.storage:

            return None



        item = (
            self.storage[key]
        )


        age = (
            time.time()
            -
            item["time"]
        )



        # cache masih valid

        if age < self.expiry:

            return item["data"]



        # cache kadaluarsa

        else:

            del self.storage[key]

            return None





    def clear(self):

        """
        Menghapus semua cache.
        """

        self.storage.clear()





    def exists(
        self,
        key
    ):

        """
        Mengecek apakah data tersedia.
        """

        return key in self.storage