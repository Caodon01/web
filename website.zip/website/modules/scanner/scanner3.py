# modules/scanner/scanner.py


class StockScanner:

    def __init__(self, stocks_data):

        self.stocks_data = stocks_data



    def scan(self):

        return []