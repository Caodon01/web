# modules/analysis/summary.py


class SummaryAnalyzer:
    """
    Membuat ringkasan hasil analisa saham.
    """



    def __init__(
        self,
        score,
        trend,
        support,
        resistance,
        volume,
        breakout,
        candlestick,
        indicators
    ):

        self.score = score

        self.trend = trend

        self.support = support

        self.resistance = resistance

        self.volume = volume

        self.breakout = breakout

        self.candlestick = candlestick

        self.indicators = indicators



    def generate(self):

        score = self.score["score"]



        # Menentukan kualitas

        if score >= 85:

            rating = "SANGAT KUAT"


        elif score >= 70:

            rating = "MENARIK"


        elif score >= 50:

            rating = "NETRAL"


        else:

            rating = "LEMAH"





        # Membuat kesimpulan

        if (
            self.breakout.get("type")
            ==
            "VALID_BREAKOUT"
        ):

            conclusion = (
                "Harga berhasil breakout "
                "dengan dukungan volume."
            )


        elif (
            self.breakout.get("type")
            ==
            "FALSE_BREAKOUT_RISK"
        ):

            conclusion = (
                "Breakout terjadi tetapi "
                "volume belum mendukung."
            )


        else:

            conclusion = (
                "Belum ada sinyal breakout."
            )





        return {


            "score":

            score,


            "rating":

            rating,


            "trend":

            self.trend["trend"],


            "support":

            self.support["support"],


            "resistance":

            self.resistance["resistance"],


            "volume":

            self.volume["status"],


            "candlestick":

            self.candlestick,


            "conclusion":

            conclusion

        }