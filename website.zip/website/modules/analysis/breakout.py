# modules/analysis/breakout.py

class BreakoutAnalyzer:
    """
    Modul pendeteksi breakout.

    Membutuhkan hasil:
    - resistance
    - trend
    - volume
    """


    def __init__(
        self,
        data,
        resistance,
        trend,
        volume
    ):

        self.data = data.copy()

        self.resistance = resistance

        self.trend = trend

        self.volume = volume



    def check_breakout(self):

        current_price = (
            self.data["close"]
            .iloc[-1]
        )


        resistance_price = (
            self.resistance
            ["resistance"]
        )


        volume_status = (
            self.volume
            ["status"]
        )


        trend_status = (
            self.trend
            ["trend"]
        )



        # Jika tidak ada resistance

        if resistance_price is None:

            return {

                "breakout": False,

                "status": "NO_RESISTANCE"

            }




        # Harga berhasil menembus resistance

        price_break = (
            current_price >
            resistance_price
        )



        # Breakout valid

        if (
            price_break
            and
            volume_status == "STRONG"
            and
            trend_status == "UPTREND"
        ):

            return {

                "breakout": True,

                "type": "VALID_BREAKOUT",

                "confidence": "HIGH",

                "reason": [

                    "Price above resistance",

                    "Volume increased",

                    "Trend bullish"

                ]

            }



        # False breakout

        elif (
            price_break
            and
            volume_status != "STRONG"
        ):

            return {

                "breakout": True,

                "type": "FALSE_BREAKOUT_RISK",

                "confidence": "LOW",

                "reason": [

                    "Price broke resistance",

                    "Volume confirmation weak"

                ]

            }




        else:

            return {

                "breakout": False,

                "type": "NO_BREAKOUT",

                "confidence": "NONE"

            }