# modules/analysis/trend.py

import pandas as pd


class TrendAnalyzer:
    """
    Modul analisa trend harga.
    
    Input:
    DataFrame dengan kolom:
    open
    high
    low
    close
    volume
    """

    def __init__(self, data):
        self.data = data.copy()


    def analyze(self):

        highs = self.data["high"]
        lows = self.data["low"]


        higher_high = 0
        higher_low = 0

        lower_high = 0
        lower_low = 0


        for i in range(1, len(self.data)):

            # Membaca Higher High dan Lower High

            if highs.iloc[i] > highs.iloc[i-1]:
                higher_high += 1

            elif highs.iloc[i] < highs.iloc[i-1]:
                lower_high += 1


            # Membaca Higher Low dan Lower Low

            if lows.iloc[i] > lows.iloc[i-1]:
                higher_low += 1

            elif lows.iloc[i] < lows.iloc[i-1]:
                lower_low += 1



        # Menentukan trend

        if higher_high > lower_high and higher_low > lower_low:

            trend = "UPTREND"
            strength = (
                higher_high +
                higher_low
            )


        elif lower_high > higher_high and lower_low > higher_low:

            trend = "DOWNTREND"
            strength = (
                lower_high +
                lower_low
            )


        else:

            trend = "SIDEWAYS"
            strength = 0



        return {

            "trend": trend,

            "strength": strength,

            "structure": {

                "higher_high": higher_high,

                "higher_low": higher_low,

                "lower_high": lower_high,

                "lower_low": lower_low
            }
        }



    def latest_price(self):

        return self.data["close"].iloc[-1]