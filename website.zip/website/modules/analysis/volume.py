# modules/analysis/volume.py

import pandas as pd


class VolumeAnalyzer:
    """
    Modul analisa volume transaksi.

    Input:
    DataFrame:
    open
    high
    low
    close
    volume
    """

    def __init__(self, data):
        self.data = data.copy()



    def analyze(self, period=20):

        volume = self.data["volume"]


        current_volume = volume.iloc[-1]


        average_volume = (
            volume
            .rolling(period)
            .mean()
            .iloc[-1]
        )


        if average_volume == 0:

            return {

                "status": "UNKNOWN",

                "strength": 0

            }



        volume_ratio = (
            current_volume /
            average_volume
        )



        # Volume meningkat kuat

        if volume_ratio >= 1.5:

            status = "STRONG"

            strength = 100



        # Volume sedikit meningkat

        elif volume_ratio >= 1:

            status = "NORMAL"

            strength = 60



        # Volume melemah

        else:

            status = "WEAK"

            strength = 30



        return {

            "current_volume": current_volume,

            "average_volume": round(
                average_volume,
                2
            ),

            "ratio": round(
                volume_ratio,
                2
            ),

            "status": status,

            "strength": strength

        }



    def trend(self, period=5):

        """
        Membaca arah volume beberapa candle terakhir
        """

        recent_volume = (
            self.data["volume"]
            .tail(period)
        )


        if recent_volume.is_monotonic_increasing:

            return "INCREASING"


        elif recent_volume.is_monotonic_decreasing:

            return "DECREASING"


        else:

            return "MIXED"