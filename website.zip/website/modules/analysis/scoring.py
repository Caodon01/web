# modules/analysis/scoring.py


class ScoringAnalyzer:
    """
    Menggabungkan seluruh hasil analisa
    menjadi skor 0-100
    """



    def __init__(
        self,
        trend,
        volume,
        breakout,
        candlestick,
        indicators,
        support,
        resistance
    ):

        self.trend = trend

        self.volume = volume

        self.breakout = breakout

        self.candlestick = candlestick

        self.indicators = indicators

        self.support = support

        self.resistance = resistance



    def calculate(self):

        score = 0


        details = {}



        # =================
        # TREND (20)
        # =================

        if (
            self.trend["trend"]
            ==
            "UPTREND"
        ):

            score += 20

            details["trend"] = 20


        elif (
            self.trend["trend"]
            ==
            "SIDEWAYS"
        ):

            score += 10

            details["trend"] = 10


        else:

            details["trend"] = 0




        # =================
        # VOLUME (20)
        # =================

        if (
            self.volume["status"]
            ==
            "STRONG"
        ):

            score += 20

            details["volume"] = 20


        elif (
            self.volume["status"]
            ==
            "NORMAL"
        ):

            score += 10

            details["volume"] = 10


        else:

            details["volume"] = 0





        # =================
        # BREAKOUT (20)
        # =================

        if (
            self.breakout.get("type")
            ==
            "VALID_BREAKOUT"
        ):

            score += 20

            details["breakout"] = 20


        elif (
            self.breakout.get("type")
            ==
            "FALSE_BREAKOUT_RISK"
        ):

            score += 5

            details["breakout"] = 5


        else:

            details["breakout"] = 0





        # =================
        # CANDLESTICK (15)
        # =================

        patterns = self.candlestick


        bullish_patterns = [

            "HAMMER",

            "BULLISH_ENGULFING"

        ]


        if any(
            p in patterns
            for p in bullish_patterns
        ):

            score += 15

            details["candlestick"] = 15


        else:

            details["candlestick"] = 0






        # =================
        # INDICATOR (15)
        # =================

        indicator_score = 0



        if (
            self.indicators["ma"]
            ["status"]
            ==
            "BULLISH"
        ):

            indicator_score += 5



        if (
            self.indicators["macd"]
            ["status"]
            ==
            "BULLISH"
        ):

            indicator_score += 5



        if (
            self.indicators["rsi"]
            ["status"]
            ==
            "NORMAL"
        ):

            indicator_score += 5



        score += indicator_score


        details["indicator"] = (
            indicator_score
        )






        # =================
        # SUPPORT RESISTANCE (10)
        # =================

        if (
            self.support["strength"]
            >= 2
        ):

            score += 5

            details["support"] = 5


        else:

            details["support"] = 0



        if (
            self.resistance["strength"]
            >= 2
        ):

            score += 5

            details["resistance"] = 5


        else:

            details["resistance"] = 0





        return {

            "score": score,

            "details": details

        }