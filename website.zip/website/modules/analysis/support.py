# modules/analysis/support.py

import pandas as pd


class SupportAnalyzer:
    """
    Modul untuk mencari area support harga.

    Input:
    DataFrame:
    open
    high
    low
    close
    volume
    """

    def __init__(self, data):
        self.data = data.copy()



    def find_support(self):

        lows = self.data["low"].tolist()


        support_levels = []


        # mencari titik low yang sering disentuh

        for i in range(1, len(lows)-1):

            previous_low = lows[i-1]
            current_low = lows[i]
            next_low = lows[i+1]


            # titik pantulan bawah

            if (
                current_low <= previous_low
                and
                current_low <= next_low
            ):

                support_levels.append(current_low)



        if len(support_levels) == 0:

            return {
                "support": None,
                "strength": 0
            }



        # Mengambil support yang paling sering muncul

        support_price = (
            pd.Series(support_levels)
            .value_counts()
            .idxmax()
        )


        strength = (
            pd.Series(support_levels)
            .value_counts()
            .max()
        )


        return {

            "support": support_price,

            "strength": strength,

            "touches": support_levels

        }



    def distance_from_price(self):

        support = self.find_support()["support"]

        current_price = (
            self.data["close"].iloc[-1]
        )


        if support is None:

            return None


        distance = (
            (current_price - support)
            /
            current_price
        ) * 100


        return round(distance, 2)