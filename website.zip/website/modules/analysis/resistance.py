# modules/analysis/resistance.py

import pandas as pd


class ResistanceAnalyzer:
    """
    Modul untuk mencari area resistance harga.

    Input:
    DataFrame:
    open
    high
    low
    close
    volume
    """

    def __init__(self, data):
        self.data = data.copy()



    def find_resistance(self):

        highs = self.data["high"].tolist()


        resistance_levels = []


        # mencari titik high yang sering tertahan

        for i in range(1, len(highs)-1):

            previous_high = highs[i-1]
            current_high = highs[i]
            next_high = highs[i+1]


            # titik puncak lokal

            if (
                current_high >= previous_high
                and
                current_high >= next_high
            ):

                resistance_levels.append(current_high)



        if len(resistance_levels) == 0:

            return {

                "resistance": None,

                "strength": 0

            }



        # mengambil resistance yang paling sering muncul

        resistance_price = (
            pd.Series(resistance_levels)
            .value_counts()
            .idxmax()
        )


        strength = (
            pd.Series(resistance_levels)
            .value_counts()
            .max()
        )


        return {

            "resistance": resistance_price,

            "strength": strength,

            "touches": resistance_levels

        }



    def distance_from_price(self):

        resistance = self.find_resistance()["resistance"]

        current_price = (
            self.data["close"].iloc[-1]
        )


        if resistance is None:

            return None


        distance = (
            (resistance - current_price)
            /
            current_price
        ) * 100


        return round(distance, 2)