# modules/analysis/indicators.py

import pandas as pd


class IndicatorAnalyzer:
    """
    Modul indikator teknikal.

    Input:
    DataFrame:
    open
    high
    low
    close
    volume
    """


    def __init__(self, data):

        self.data = data.copy()



    def moving_average(self, period=20):

        """
        Menghitung Moving Average
        """

        ma = (
            self.data["close"]
            .rolling(period)
            .mean()
        )


        current_price = (
            self.data["close"]
            .iloc[-1]
        )


        current_ma = ma.iloc[-1]


        if current_price > current_ma:

            status = "BULLISH"


        else:

            status = "BEARISH"



        return {

            "period": period,

            "ma": round(current_ma, 2),

            "price": current_price,

            "status": status

        }




    def rsi(self, period=14):

        """
        Menghitung RSI
        """

        delta = (
            self.data["close"]
            .diff()
        )


        gain = delta.where(
            delta > 0,
            0
        )


        loss = -delta.where(
            delta < 0,
            0
        )


        avg_gain = (
            gain
            .rolling(period)
            .mean()
        )


        avg_loss = (
            loss
            .rolling(period)
            .mean()
        )


        rs = avg_gain / avg_loss


        rsi = (
            100 -
            (100 / (1 + rs))
        )


        current_rsi = rsi.iloc[-1]


        if current_rsi >= 70:

            status = "OVERBOUGHT"


        elif current_rsi <= 30:

            status = "OVERSOLD"


        else:

            status = "NORMAL"



        return {

            "value": round(
                current_rsi,
                2
            ),

            "status": status

        }





    def macd(
        self,
        fast=12,
        slow=26,
        signal=9
    ):

        """
        Menghitung MACD
        """

        ema_fast = (
            self.data["close"]
            .ewm(span=fast)
            .mean()
        )


        ema_slow = (
            self.data["close"]
            .ewm(span=slow)
            .mean()
        )


        macd_line = (
            ema_fast -
            ema_slow
        )


        signal_line = (
            macd_line
            .ewm(span=signal)
            .mean()
        )


        current_macd = macd_line.iloc[-1]

        current_signal = signal_line.iloc[-1]


        if current_macd > current_signal:

            status = "BULLISH"


        else:

            status = "BEARISH"



        return {

            "macd": round(
                current_macd,
                2
            ),

            "signal": round(
                current_signal,
                2
            ),

            "status": status

        }