# modules/analysis/candlestick.py

class CandlestickAnalyzer:
    """
    Modul analisa pola candlestick.

    Input:
    DataFrame:
    open
    high
    low
    close
    """

    def __init__(self, data):

        self.data = data.copy()



    def last_candle(self):

        """
        Mengambil candle terakhir
        """

        return self.data.iloc[-1]



    def detect(self):

        candle = self.last_candle()


        open_price = candle["open"]

        close_price = candle["close"]

        high_price = candle["high"]

        low_price = candle["low"]



        body = abs(
            close_price -
            open_price
        )


        upper_shadow = (
            high_price -
            max(
                open_price,
                close_price
            )
        )


        lower_shadow = (
            min(
                open_price,
                close_price
            )
            -
            low_price
        )



        result = []



        # Hammer

        if (
            lower_shadow > body * 2
            and
            upper_shadow < body
        ):

            result.append(
                "HAMMER"
            )



        # Doji

        if body <= (
            (high_price-low_price)
            * 0.1
        ):

            result.append(
                "DOJI"
            )



        # Bullish / Bearish Engulfing

        if len(self.data) >= 2:

            previous = (
                self.data.iloc[-2]
            )


            prev_open = previous["open"]

            prev_close = previous["close"]



            # Bullish Engulfing

            if (
                prev_close < prev_open
                and
                close_price > open_price
                and
                close_price > prev_open
                and
                open_price < prev_close
            ):

                result.append(
                    "BULLISH_ENGULFING"
                )



            # Bearish Engulfing

            if (
                prev_close > prev_open
                and
                close_price < open_price
                and
                close_price < prev_open
                and
                open_price > prev_close
            ):

                result.append(
                    "BEARISH_ENGULFING"
                )



        if len(result) == 0:

            result.append(
                "NO_PATTERN"
            )



        return result