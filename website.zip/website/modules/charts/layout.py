# modules/charts/layout.py

from plotly.subplots import make_subplots


class ChartLayout:

    @staticmethod
    def create(
        candle_trace,
        volume_trace,
        indicator_traces=None,
        title="Stock Chart"
    ):
        """
        Membuat layout chart utama.

        candle_trace:
            Candlestick chart

        volume_trace:
            Volume chart

        indicator_traces:
            List indikator seperti MA, RSI, MACD

        """

        fig = make_subplots(
            rows=2,
            cols=1,
            shared_xaxes=True,
            vertical_spacing=0.03,
            row_heights=[
                0.75,
                0.25
            ]
        )


        # =========================
        # Candlestick
        # =========================

        fig.add_trace(
            candle_trace,
            row=1,
            col=1
        )


        # =========================
        # Indicators
        # =========================

        if indicator_traces:

            for indicator in indicator_traces:

                fig.add_trace(
                    indicator,
                    row=1,
                    col=1
                )


        # =========================
        # Volume
        # =========================

        fig.add_trace(
            volume_trace,
            row=2,
            col=1
        )


        # =========================
        # Chart Appearance
        # =========================

        fig.update_layout(

            title={
                "text": title,
                "x": 0.5
            },

            height=850,

            template="plotly_dark",

            hovermode="x unified",

            showlegend=True,

            xaxis_rangeslider_visible=False
        )


        # =========================
        # Axis
        # =========================

        fig.update_yaxes(
            title_text="Price",
            row=1,
            col=1
        )


        fig.update_yaxes(
            title_text="Volume",
            row=2,
            col=1
        )


        return fig