"""
modules/charts/volume.py

Volume Chart Engine
BEI Trading Assistant AI
Versi 1.0

File ini hanya membuat TRACE volume.
Bukan membuat Figure.

Figure akan dibuat di layout.py
"""

import plotly.graph_objects as go


class VolumeChart:

    @staticmethod
    def create_trace(data):
        """
        Membuat trace volume.

        Parameters
        ----------
        data : pandas.DataFrame

        Returns
        -------
        plotly.graph_objects.Bar
        """

        colors = []

        for open_price, close_price in zip(data["Open"], data["Close"]):

            if close_price >= open_price:
                colors.append("#00C853")      # Hijau

            else:
                colors.append("#FF1744")      # Merah

        trace = go.Bar(

            x=data.index,

            y=data["Volume"],

            name="Volume",

            marker=dict(

                color=colors

            ),

            opacity=0.8

        )

        return trace