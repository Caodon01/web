"""
modules/charts/indicators.py

Indicator Engine
BEI Trading Assistant AI

Semua indikator teknikal dibuat di sini.
Digunakan oleh:

- Chart Engine
- Analysis Engine
- Scanner
- AI Assistant
"""

import pandas as pd


class IndicatorEngine:

    # =======================================
    # SMA
    # =======================================

    @staticmethod
    def sma(data, period):

        return data["Close"].rolling(period).mean()

    # =======================================
    # EMA
    # =======================================

    @staticmethod
    def ema(data, period):

        return data["Close"].ewm(
            span=period,
            adjust=False
        ).mean()

    # =======================================
    # RSI
    # =======================================

    @staticmethod
    def rsi(data, period=14):

        delta = data["Close"].diff()

        gain = delta.clip(lower=0)

        loss = -delta.clip(upper=0)

        avg_gain = gain.rolling(period).mean()

        avg_loss = loss.rolling(period).mean()

        rs = avg_gain / avg_loss

        rsi = 100 - (100 / (1 + rs))

        return rsi

    # =======================================
    # MACD
    # =======================================

    @staticmethod
    def macd(
        data,
        fast=12,
        slow=26,
        signal=9
    ):

        ema_fast = IndicatorEngine.ema(data, fast)

        ema_slow = IndicatorEngine.ema(data, slow)

        macd = ema_fast - ema_slow

        signal_line = macd.ewm(
            span=signal,
            adjust=False
        ).mean()

        histogram = macd - signal_line

        return macd, signal_line, histogram

    # =======================================
    # Bollinger Band
    # =======================================

    @staticmethod
    def bollinger(
        data,
        period=20,
        std=2
    ):

        sma = IndicatorEngine.sma(data, period)

        sigma = data["Close"].rolling(period).std()

        upper = sma + std * sigma

        lower = sma - std * sigma

        return upper, sma, lower

    # =======================================
    # ATR
    # =======================================

    @staticmethod
    def atr(
        data,
        period=14
    ):

        high_low = data["High"] - data["Low"]

        high_close = (
            data["High"]
            - data["Close"].shift()
        ).abs()

        low_close = (
            data["Low"]
            - data["Close"].shift()
        ).abs()

        tr = pd.concat(

            [
                high_low,
                high_close,
                low_close
            ],

            axis=1

        ).max(axis=1)

        atr = tr.rolling(period).mean()

        return atr