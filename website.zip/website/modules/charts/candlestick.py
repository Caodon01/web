"""
modules/charts/candlestick.py

Chart Engine BEI Trading Assistant AI
Versi : 1.0

Fitur:
- Candlestick
- Moving Average 20
- Moving Average 50
- Support
- Resistance
- Breakout Marker
- Output HTML Plotly
"""

import pandas as pd
import plotly.graph_objects as go


class CandlestickChart:

    @staticmethod
    def create(
        data: pd.DataFrame,
        symbol: str = "SAHAM",
        support=None,
        resistance=None,
        breakout=None,
    ):
        """
        Membuat chart candlestick lengkap.

        Parameters
        ----------
        data : DataFrame

        symbol : str

        support : float | None

        resistance : float | None

        breakout : float | None
        """

        df = data.copy()

        # ==========================
        # Moving Average
        # ==========================

        df["MA20"] = df["Close"].rolling(20).mean()
        df["MA50"] = df["Close"].rolling(50).mean()

        fig = go.Figure()

        # ==========================
        # Candlestick
        # ==========================

        fig.add_trace(

            go.Candlestick(

                x=df.index,

                open=df["Open"],

                high=df["High"],

                low=df["Low"],

                close=df["Close"],

                name="Candlestick",

                increasing_line_color="#00C853",

                decreasing_line_color="#FF1744"

            )

        )

        # ==========================
        # MA20
        # ==========================

        fig.add_trace(

            go.Scatter(

                x=df.index,

                y=df["MA20"],

                mode="lines",

                name="MA20",

                line=dict(

                    color="orange",

                    width=2

                )

            )

        )

        # ==========================
        # MA50
        # ==========================

        fig.add_trace(

            go.Scatter(

                x=df.index,

                y=df["MA50"],

                mode="lines",

                name="MA50",

                line=dict(

                    color="blue",

                    width=2

                )

            )

        )

        # ==========================
        # Support
        # ==========================

        if support is not None:

            fig.add_hline(

                y=support,

                line_dash="dot",

                line_color="green",

                annotation_text="Support"

            )

        # ==========================
        # Resistance
        # ==========================

        if resistance is not None:

            fig.add_hline(

                y=resistance,

                line_dash="dot",

                line_color="red",

                annotation_text="Resistance"

            )

        # ==========================
        # Breakout
        # ==========================

        if breakout is not None:

            fig.add_hline(

                y=breakout,

                line_dash="dash",

                line_color="purple",

                annotation_text="Breakout"

            )

        # ==========================
        # Layout
        # ==========================

        fig.update_layout(

            title=f"{symbol} Candlestick Chart",

            template="plotly_white",

            height=700,

            hovermode="x unified",

            xaxis_rangeslider_visible=False,

            legend=dict(

                orientation="h",

                yanchor="bottom",

                y=1.02,

                xanchor="right",

                x=1

            ),

            margin=dict(

                l=20,

                r=20,

                t=60,

                b=20

            )

        )

        fig.update_xaxes(

            showgrid=True

        )

        fig.update_yaxes(

            showgrid=True

        )

        return fig

    @staticmethod
    def to_html(fig):
        """
        Mengubah Plotly Figure menjadi HTML
        agar bisa ditampilkan di Flask.
        """

        return fig.to_html(
            full_html=False,
            include_plotlyjs="cdn"
        )