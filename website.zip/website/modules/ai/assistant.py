# modules/ai/assistant.py


class TradingAssistant:
    """
    AI Assistant untuk menjelaskan
    hasil analisa saham.
    """



    def __init__(self, analysis_result):

        self.result = analysis_result



    def generate_report(self):

        symbol = (
            self.result["symbol"]
        )


        score = (
            self.result["score"]
        )


        rating = (
            self.result["rating"]
        )


        trend = (
            self.result["trend"]
        )


        support = (
            self.result["support"]
        )


        resistance = (
            self.result["resistance"]
        )


        volume = (
            self.result["volume"]
        )


        conclusion = (
            self.result["conclusion"]
        )



        report = f"""

=========================
ANALISA SAHAM {symbol}
=========================


Score:
{score}/100


Rating:
{rating}


Trend:
{trend}


Support:
{support}


Resistance:
{resistance}


Volume:
{volume}



KESIMPULAN:

{conclusion}



MANAJEMEN RISIKO:

- Perhatikan area support.
- Jangan mengejar harga terlalu jauh.
- Gunakan stop loss jika struktur trend rusak.


=========================

"""


        return report




    def compare_stocks(self, stocks):

        """
        Membandingkan beberapa saham
        """

        ranking = sorted(

            stocks,

            key=lambda x:
            x["score"],

            reverse=True

        )


        result = []


        for i, stock in enumerate(
            ranking,
            start=1
        ):

            result.append({

                "rank": i,

                "symbol":
                stock["symbol"],

                "score":
                stock["score"]

            })


        return result