/* =====================================================
   BEI Trading Assistant AI
   MAIN.JS
===================================================== */

document.addEventListener("DOMContentLoaded", function () {

    const sidebar = document.getElementById("sidebar");
    const overlay = document.getElementById("overlay");
    const openBtn = document.getElementById("openSidebar");
    const closeBtn = document.getElementById("closeSidebar");

    // ==========================
    // Buka Sidebar
    // ==========================
    if (openBtn) {
        openBtn.addEventListener("click", function () {
            sidebar.classList.add("active");
            overlay.classList.add("active");
        });
    }

    // ==========================
    // Tutup Sidebar
    // ==========================
    if (closeBtn) {
        closeBtn.addEventListener("click", function () {
            sidebar.classList.remove("active");
            overlay.classList.remove("active");
        });
    }

    // ==========================
    // Klik Overlay
    // ==========================
    if (overlay) {
        overlay.addEventListener("click", function () {
            sidebar.classList.remove("active");
            overlay.classList.remove("active");
        });
    }

    // ==========================
    // Tutup Sidebar Saat Klik Menu (HP)
    // ==========================
    const menuLinks = document.querySelectorAll(".sidebar .nav-link");

    menuLinks.forEach(function (link) {

        link.addEventListener("click", function () {

            if (window.innerWidth < 992) {

                sidebar.classList.remove("active");
                overlay.classList.remove("active");

            }

        });

    });

    // ==========================
    // Highlight Menu Aktif
    // ==========================
    const currentPath = window.location.pathname;

    menuLinks.forEach(function (link) {

        if (link.getAttribute("href") === currentPath) {

            link.classList.add("active");

        }

    });

    // ==========================
    // Efek Hover Card
    // ==========================
    const cards = document.querySelectorAll(".card");

    cards.forEach(function (card) {

        card.addEventListener("mouseenter", function () {

            card.style.transform = "translateY(-5px)";
            card.style.transition = "0.25s";

        });

        card.addEventListener("mouseleave", function () {

            card.style.transform = "translateY(0px)";

        });

    });

    // ==========================
    // Tombol Scroll ke Atas
    // ==========================
    const scrollBtn = document.createElement("button");

    scrollBtn.innerHTML = "↑";

    scrollBtn.id = "scrollTop";

    document.body.appendChild(scrollBtn);

    scrollBtn.style.position = "fixed";
    scrollBtn.style.right = "20px";
    scrollBtn.style.bottom = "20px";
    scrollBtn.style.width = "45px";
    scrollBtn.style.height = "45px";
    scrollBtn.style.borderRadius = "50%";
    scrollBtn.style.border = "none";
    scrollBtn.style.background = "#00c853";
    scrollBtn.style.color = "#fff";
    scrollBtn.style.fontSize = "22px";
    scrollBtn.style.cursor = "pointer";
    scrollBtn.style.display = "none";
    scrollBtn.style.zIndex = "999";

    window.addEventListener("scroll", function () {

        if (window.scrollY > 250) {

            scrollBtn.style.display = "block";

        } else {

            scrollBtn.style.display = "none";

        }

    });

    scrollBtn.addEventListener("click", function () {

        window.scrollTo({

            top: 0,
            behavior: "smooth"

        });

    });

});