import random


class AnalysisService:

    @staticmethod
    def analyze(symbol):

        symbol = symbol.upper()

        return {
            "symbol": symbol,
            "price": round(random.uniform(100, 10000), 2),
            "trend": "Bullish",
            "support": round(random.uniform(100, 9000), 2),
            "resistance": round(random.uniform(9000, 12000), 2),
            "rsi": random.randint(30, 80),
            "macd": "Golden Cross",
            "volume": "High",
            "recommendation": "BUY"
        }


# Tetap disediakan agar kode lama yang memakai analyze_stock()
# masih bisa berjalan.
def analyze_stock(symbol):
    return AnalysisService.analyze(symbol)