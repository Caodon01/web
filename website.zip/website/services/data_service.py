import yfinance as yf

class DataService:

    @staticmethod
    def get_history(symbol, period="6mo"):

        symbol = symbol.upper()

        if not symbol.endswith(".JK"):
            symbol += ".JK"

        ticker = yf.Ticker(symbol)

        return ticker.history(period=period)

    @staticmethod
    def get_info(symbol):

        symbol = symbol.upper()

        if not symbol.endswith(".JK"):
            symbol += ".JK"

        ticker = yf.Ticker(symbol)

        return ticker.info