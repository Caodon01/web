from services.data_service import DataService

from modules.data.validator import DataValidator

from modules.analysis.trend import TrendAnalyzer
from modules.analysis.support import SupportAnalyzer
from modules.analysis.resistance import ResistanceAnalyzer
from modules.analysis.volume import VolumeAnalyzer
from modules.analysis.indicators import IndicatorAnalyzer
from modules.analysis.breakout import BreakoutAnalyzer
from modules.analysis.candlestick import CandlestickAnalyzer
from modules.analysis.scoring import ScoringAnalyzer
from modules.analysis.summary import SummaryAnalyzer



class AnalysisService:


    @staticmethod
    def analyze(symbol):


        # =========================
        # Ambil Data
        # =========================

        df = DataService.get_history(symbol)


        if df.empty:

            return None



        # =========================
        # Validasi Data
        # =========================

        validator = DataValidator(df)

        validation = validator.validate()


        if not validation["valid"]:

            return {

                "error":
                "Data tidak valid",

                "details":
                validation

            }




        # =========================
        # Trend
        # =========================

        trend = TrendAnalyzer(df).analyze()



        # =========================
        # Support
        # =========================

        support = SupportAnalyzer(df).find_support()



        # =========================
        # Resistance
        # =========================

        resistance = ResistanceAnalyzer(df).find_resistance()



        # =========================
        # Volume
        # =========================

        volume = VolumeAnalyzer(df).analyze()




        # =========================
        # Indicators
        # =========================

        indicator_engine = IndicatorAnalyzer(df)


        indicators = {

            "ma":
            indicator_engine.moving_average(),


            "rsi":
            indicator_engine.rsi(),


            "macd":
            indicator_engine.macd()

        }





        # =========================
        # Breakout
        # =========================

        breakout = BreakoutAnalyzer(

            df,

            resistance,

            trend,

            volume

        ).check_breakout()




        # =========================
        # Candlestick
        # =========================

        candlestick = (

            CandlestickAnalyzer(df)
            .detect()

        )




        # =========================
        # Scoring
        # =========================

        score = ScoringAnalyzer(

            trend,

            volume,

            breakout,

            candlestick,

            indicators,

            support,

            resistance

        ).calculate()





        # =========================
        # Summary
        # =========================

        summary = SummaryAnalyzer(

            score,

            trend,

            support,

            resistance,

            volume,

            breakout,

            candlestick,

            indicators

        ).generate()





        # =========================
        # Data tambahan harga
        # =========================

        latest = df.iloc[-1]

        previous = df.iloc[-2]


        change = (
            latest["Close"]
            -
            previous["Close"]
        )


        change_percent = (

            change /
            previous["Close"]

        ) * 100





        summary.update({

            "symbol":
            symbol.upper(),


            "price":
            round(
                float(latest["Close"]),
                2
            ),


            "open":
            round(
                float(latest["Open"]),
                2
            ),


            "high":
            round(
                float(latest["High"]),
                2
            ),


            "low":
            round(
                float(latest["Low"]),
                2
            ),


            "volume":
            int(
                latest["Volume"]
            ),


            "change":
            round(
                float(change),
                2
            ),


            "change_percent":
            round(
                float(change_percent),
                2
            )

        })



        return summary




def analyze_stock(symbol):

    return AnalysisService.analyze(symbol)