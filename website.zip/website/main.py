# main.py


from modules.scanner.scanner3 import StockScanner
from modules.ai.assistant import TradingAssistant



def run_analysis():

    """
    Program utama analisa saham
    """



    # =========================
    # DATA SAHAM
    # sementara masih dummy
    # nanti diganti fetcher.py
    # =========================


    stocks_data = {

        # contoh:
        # "BBRI": dataframe,
        # "BBCA": dataframe

    }




    # =========================
    # SCANNER
    # =========================


    scanner = StockScanner(
        stocks_data
    )


    results = scanner.scan()



    # =========================
    # Tampilkan ranking
    # =========================


    print(
        "RANKING SAHAM"
    )


    for stock in results:

        print(
            stock["symbol"],
            stock["score"]
        )




    # =========================
    # AI ASSISTANT
    # =========================


    if len(results) > 0:


        best_stock = results[0]


        assistant = TradingAssistant(
            best_stock
        )


        report = (
            assistant
            .generate_report()
        )


        print(report)




if __name__ == "__main__":

    run_analysis()